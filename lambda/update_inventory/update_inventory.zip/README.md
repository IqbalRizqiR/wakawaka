# Environment Variables

`DB_HOST=your endpoint RDS`<br/>
`DB_NAME=your name database`<br/>
`DB_USER=username`<br/>
`DB_PASSWORD=yourpassword`<br/>
`S3_BUCKET=yourname bucket`<br/>
