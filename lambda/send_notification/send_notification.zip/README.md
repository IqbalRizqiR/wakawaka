# Environment Variables

SNS_TOPIC_ARN=your ARN SNS