# Environment Variables

`DB_HOST=[RDS endpoint]`<br/>
`DB_NAME=yourname db` <br/>
`DB_USER=your passwrod db` <br/>
`DB_PASSWORD=TechnoCloud2026!`<br/>
`S3_BUCKET=yourbucket` <br/>
`STATE_MACHINE_ARN=ARN Step Functions state machine`