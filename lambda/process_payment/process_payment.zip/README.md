# Environment Variables

`ORDER_MANAGEMENT_FUNCTION=lks-lambda-order-management`<br/>
`NOTIFICATION_FUNCTION=lks-lambda-send-notification`<br/>