# Environment Variables

`DB_HOST=endpoint RDS`<br/>
`DB_NAME=your name database`<br/>
`DB_USER=your user`<br/>
`DB_PASSWORD=yourpassword`<br/>
`S3_BUCKET=yourname bucket`<br/>